# simulated configuration
